// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonGame
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonGame"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_game display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_GAME
#define _H_NONNON_MAC_NONNON_GAME




#import <Cocoa/Cocoa.h>
//#import <AVFoundation/AVFoundation.h>




#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/image.c"
#include "../../nonnon/mac/sound.c"
#include "../../nonnon/mac/window.c"

#include "../../nonnon/mac/gamepad.c"




@interface NonnonGame : NSView
//@interface NonnonGame : NSView <AVAudioPlayerDelegate>
@end




#include "lm2.c"




@interface NonnonGame ()

@end


@implementation NonnonGame {

	n_lm2    lm2;
	NSRect   lm2_rect;

	NSTimer *n_nstimer_launch;

}


- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{

		n_lm2_zero( &lm2 );

		lm2.self = self;

		[[NSNotificationCenter defaultCenter]
			addObserver: self
			   selector: @selector( n_DidConnectNotification: )
			       name: GCControllerDidConnectNotification
			     object: nil
		];

		[[NSNotificationCenter defaultCenter]
			addObserver: self
			   selector: @selector( n_DidDisconnectNotification: )
			       name: GCControllerDidDisconnectNotification
			     object: nil
		];

	}


	return self;
}

- (void) n_mac_game_init
{
	// [!] : call at awakeFromNib

	n_lm2_init( &lm2 );
//NSLog( @"%d %d", lm2.sx, lm2.sy );


	// [x] : Sonoma : glitch prevention
	n_nstimer_launch = n_mac_timer_init( self, @selector( n_timer_method_launch ), 200 );

}




- (void) n_timer_method_launch
{
//NSLog( @"n_timer_method_launch" );

	n_mac_timer_init( self, @selector( n_timer_method ), 1 );

	n_mac_timer_exit( n_nstimer_launch );

}




- (void) n_DidConnectNotification:(NSNotification *)notification
{
//NSLog( @"n_DidConnectNotification" );

	lm2.gamepad = n_mac_gamepad_init();
	lm2.gamepad.valueChangedHandler = ^(GCExtendedGamepad * _Nonnull gamepad, GCControllerElement * _Nonnull element) {
//static int i = 0; NSLog( @"valueChangedHandler : %d", i ); i++;

		self->lm2.input_any_keys_onoff = n_posix_true;

	};

}

- (void) n_DidDisconnectNotification:(NSNotification *)notification
{
//NSLog( @"n_DidDisconnectNotification" );

	lm2.gamepad = nil;

}




- (void) n_mac_game_canvas_resize:(NSWindow*)window width:(n_type_gfx)sx height:(n_type_gfx)sy
{

	if ( sx == -1 ) { sx = lm2.csx; }
	if ( sy == -1 ) { sy = lm2.csy; }
//NSLog( @"%d %d", sx, sy );

	n_bmp_new( &lm2.canvas, sx, sy );
	n_bmp_flush( &lm2.canvas, lm2.color );

	NSSize size = NSMakeSize( sx,sy );

	[window setContentMinSize:size];
	[window setContentMaxSize:size];
	[window setContentSize   :size];


	lm2_rect = NSMakeRect( 0,0,sx,sy );

	[self setFrame:lm2_rect];

	n_mac_window_centering( window );

}




- (void) n_game_start
{

	// [!] : macOS Sonoma launching sequence
	//
	//	initWithCoder
	//	awakeFromNib
	//	applicationWillFinishLaunching
	//	drawRect
	//	applicationDidFinishLaunching
	//	n_timer_method

}



/*
- (BOOL) isFlipped
{
	return YES;
}
*/

- (void) n_timer_method
{
//NSLog( @"%f", CACurrentMediaTime() );


	if ( [n_mac_image_window isKeyWindow] == FALSE ) { return; }


	n_lm2 *p = &lm2;


	static u32 timer = 0;
	if ( n_game_timer( &timer, 12 ) )
	{
		n_lm2_loop( p );
	}


	static u32 timer_2 = 0;
	if ( n_game_timer( &timer_2, 12 ) )
	{

		if ( p->transition_phase != N_LM2_TRANSITION_NONE )
		{
			if ( p->transition_phase == N_LM2_TRANSITION_FADE_IN )
			{
				n_lm2_chara_draw_blend -= 0.05;

				if ( n_lm2_chara_draw_blend <= 0.0 )
				{
					p->transition_phase = N_LM2_TRANSITION_NONE;
				}
			} else
			if ( p->transition_phase == N_LM2_TRANSITION_FADE_OUT )
			{
				n_lm2_chara_draw_blend += 0.05;

				if ( n_lm2_chara_draw_blend >= 1.0 )
				{
					p->transition_phase = N_LM2_TRANSITION_FADE_IN;

					n_lm2_vibrate_off( p );

					n_lm2_reset( p );
					n_bmp_flush_fastcopy( &p->bmp[ N_LM2_BMPBG_INDEX ], &p->canvas );
				}
			}

			p->refresh = TRUE;
		}

	}


	if ( p->refresh )
	{
		p->refresh = FALSE;

		[self display];
	}

}


- (void)drawRect:(NSRect)rect
{
//NSLog( @"drawRect" );

	n_mac_image_nbmp_direct_draw( &lm2.canvas, &lm2_rect, n_posix_true );

}




- (void) NonnonLM2HighScoreReset
{

	lm2.hiscore = 0;

}

- (void) NonnonLM2HighScoreWrite
{

	n_lm2_settings_write( &lm2 );

}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");

        return YES;
}

- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d : Chars %@", event.keyCode, event.characters );


	lm2.input_any_keys_onoff = n_posix_true;


	switch( event.keyCode ) {

	case N_MAC_KEYCODE_F1:

		lm2.input |= N_LM2_INPUT_F1;

	break;

	case N_MAC_KEYCODE_F2:

		lm2.input |= N_LM2_INPUT_F2;

	break;

	case N_MAC_KEYCODE_F3:

		lm2.input |= N_LM2_INPUT_F3;

	break;

	} // switch

}

- (void) keyUp : (NSEvent*) event
{
//return;

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_F1:

		lm2.input &= ~N_LM2_INPUT_F1;

	break;

	case N_MAC_KEYCODE_F2:

		lm2.input &= ~N_LM2_INPUT_F2;

	break;

	case N_MAC_KEYCODE_F3:

		lm2.input &= ~N_LM2_INPUT_F3;

	break;

	} // switch

}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	if ( [theEvent clickCount] >= 2 )
	{
		n_mac_window_centering( self.window );
	} else {
		[self.window performWindowDragWithEvent:theEvent];
	}

}



/*
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
//NSLog(@"audioPlayerDidFinishPlaying");

	// [x] : this is called after more than sound msec

}
*/



@end


#endif // _H_NONNON_MAC_NONNON_GAME


